# SVG Quadratic Bezier Curve Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/codegridweb/pen/VwEzbqa](https://codepen.io/codegridweb/pen/VwEzbqa).

